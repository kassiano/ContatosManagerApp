<?php
/**
 * Created by PhpStorm.
 * User: kassiano
 * Date: 26/06/2016
 * Time: 20:47
 */

define("PROJECTDIR", "contatos_mvc");